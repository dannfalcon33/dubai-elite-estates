
export interface Property {
  id: string;
  name: string;
  location: string;
  price: number;
  description: string;
  details: {
    beds: number;
    baths: number;
    sqft: number;
    type: string;
  };
  images: string[];
}

export interface Realtor {
  id: string;
  name: string;
  role: string;
  image: string;
  bio: string;
}

export interface LeadFormData {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  investmentAmount: string;
  message: string;
}
